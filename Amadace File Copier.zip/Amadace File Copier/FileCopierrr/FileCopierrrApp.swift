//
//  FileCopierrrApp.swift
//  FileCopierrr
//
//

import SwiftUI

@main
struct FileCopierrrApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
